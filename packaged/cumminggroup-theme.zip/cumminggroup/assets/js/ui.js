(() => {
  // _src/js/disclosure.js
  function disclosure_default() {
    let details = document.querySelectorAll("details"), toggle = (state, { summary, details: details2 }) => {
      details2.forEach((el) => {
        el.setAttribute("aria-hidden", !state);
      });
      summary.setAttribute("aria-expanded", state);
    };
    details.forEach((el) => {
      const current = !!el.getAttribute("open"), summary = el.querySelector("summary"), details2 = el.querySelectorAll(":scope > :not(summary)");
      toggle(current, { summary, details: details2 });
      el.addEventListener("toggle", (e) => {
        toggle(e.target.open, { summary, details: details2 });
      });
      el.addEventListener("keyup", (e) => {
        if (e.key.toLowerCase() === "escape") {
          e.target.closest("[open]").removeAttribute("open");
          toggle(false, { summary, details: details2 });
        }
      });
    });
  }

  // _src/js/toggle.js
  function toggle_default() {
    const toggleEls = document.querySelectorAll("[data-toggle]"), closeEls = document.querySelectorAll("[data-toggle-close]"), getTargets = (el) => {
      if (!el) {
        return;
      }
      return el.dataset.toggle ? document.querySelectorAll(el.dataset.toggle) : [el.nextElementSibling];
    }, detectCollision = (el) => {
      const collisionObserver = new ResizeObserver((obs) => {
        obs.forEach((ob) => {
          const leftPos = ob.target.getBoundingClientRect().x;
          if (leftPos < 0) {
            ob.target.classList.add("left-collision");
          }
          if (ob.target.getBoundingClientRect().x + ob.target.offsetWidth > window.innerWidth) {
            ob.target.classList.add("right-collision");
          }
        });
      });
      collisionObserver.observe(el);
    }, init = function(el) {
      const expandedSet = el.getAttribute("aria-expanded"), sessionAttr = el.getAttribute("data-session"), initialState = !expandedSet || expandedSet === "false" ? "false" : "true", targetEls = getTargets(el);
      let state = sessionAttr !== null && localStorage.getItem(sessionAttr) !== null ? localStorage.getItem(sessionAttr).toString() : initialState.toString();
      if (expandedSet === null && sessionAttr === null) {
        state = "false";
      }
      el.setAttribute("aria-expanded", state);
      if (sessionAttr !== null && localStorage.getItem(sessionAttr) === null) {
        localStorage.setItem(sessionAttr, expandedSet);
      }
      targetEls.forEach((targetEl) => {
        targetEl.setAttribute("aria-hidden", state === "true" ? "false" : "true");
        targetEl.classList[state === "true" ? "remove" : "add"]("toggle-hidden");
      });
      el.addEventListener("click", function(e) {
        const nowCollapsed = this.getAttribute("aria-expanded") === "true";
        if (!openToggles.includes(this) && !nowCollapsed) {
          this.localName === "a" && e.preventDefault();
        }
        swapState(this, nowCollapsed);
      });
    }, closeHandler = (e) => {
      const keyPress = e.key || false;
      let targetEl;
      e.stopPropagation();
      if (openToggles.length) {
        const selectedToggles = openToggles.filter((toggle) => toggle.getAttribute("aria-expanded") === "true" && toggle.getAttribute("data-persist") === null), openToggle = selectedToggles[selectedToggles.length - 1], currentTarget = e.target.closest("[data-toggle]") !== null && e.target.closest("[data-toggle]"), openTargets = getTargets(openToggle);
        let targetEls;
        if (!openToggle) {
          return;
        }
        openTargets.forEach((openTarget) => {
          if (e.target.closest("[data-toggle-close]") !== null || !openTarget.contains(e.target) && !openToggle.contains(e.target) || keyPress === "Escape") {
            targetEls = getTargets(openToggle).forEach((targetEl2) => {
              swapState(openToggle, "true");
            });
          }
        });
      }
    }, swapState = function(el, state, related = false) {
      const targets = getTargets(el), others = el.getAttribute("data-toggle-group") && [...document.querySelectorAll(`[data-toggle-group="${el.getAttribute("data-toggle-group")}"`)].filter((grouped) => grouped !== el), toggleState = (el2, target, state2) => {
        el2.setAttribute("aria-expanded", !state2);
        target.classList.toggle("toggle-hidden", state2);
        if (el2.getAttribute("data-session") !== null) {
          localStorage.setItem(el2.getAttribute("data-session"), !state2);
        }
        targets.forEach((target2) => {
          if (target2.getAttribute("aria-hidden")) {
            target2.setAttribute("aria-hidden", state2);
          }
        });
      };
      if (state === false && others) {
        others.forEach((other) => other.getAttribute("aria-expanded") === "true" && swapState(other, true, true));
      }
      if (state && el.getAttribute("data-persist") !== null && !related) {
        return;
      }
      if (!state) {
        openToggles.push(el);
      } else {
        openToggles.splice(openToggles.indexOf(el), 1);
      }
      if (state === false && others) {
        others.forEach((other) => other.getAttribute("aria-expanded") === "true" && swapState(other, true));
      }
      targets.forEach((target) => {
        if (target === null) {
          return;
        }
        if (target.contains(document.activeElement)) {
          el.focus();
        }
        toggleState(el, target, state);
        if (!state) {
          detectCollision(target);
        }
      });
    };
    let openToggles = [...document.querySelectorAll("[data-toggle][aria-expanded='true']")];
    toggleEls.forEach((el) => {
      init(el);
    });
    closeEls.forEach((el) => {
      el.addEventListener("click", function(e) {
        const targets = document.querySelectorAll(`[data-toggle="${this.getAttribute("[data-toggle-close]")}"]`);
        [...targets].filter((toggle) => toggle.getAttribute("aria-expanded") === "true").forEach((open) => open.click());
      });
    });
    document.addEventListener("click", closeHandler);
    document.addEventListener("keyup", closeHandler);
  }

  // _src/js/menu.js
  function menu_default() {
    const toggleEls = document.querySelectorAll("[aria-haspopup]"), init = (el) => {
      el.addEventListener("click", toggleStates);
      document.addEventListener("keyup", keyHandler);
    }, closeTop = (e) => {
      const openToggle = document.querySelector('[aria-haspopup][aria-expanded="true"]');
      let targetEl;
      if (openToggle) {
        targetEl = openToggle.closest(".menu").querySelector('[role="menu"]');
        targetEl.setAttribute("aria-hidden", true);
        openToggle.setAttribute("aria-expanded", false);
      }
    }, keyHandler = (e) => {
      const current = document.activeElement, openWrap = document.querySelectorAll('[aria-hidden="false"][role="menu"]'), parentWrap = current.closest(".menu"), resultList = parentWrap && parentWrap.querySelector('[role="menu"]'), matchedSibling = (el, sel, dir) => {
        let sibEl = el[dir + "ElementSibling"];
        while (sibEl) {
          if (sibEl.matches(sel)) {
            return sibEl;
          }
          sibEl = sibEl[dir + "ElementSibling"];
        }
      };
      let moveTo;
      if (!current || !openWrap) {
        return;
      }
      if (e.key === "Escape") {
        closeTop(e, true);
        if (parentWrap) {
          parentWrap.querySelector('[aria-haspopup="true"]').focus();
        }
        return;
      }
      switch (e.key) {
        case "ArrowDown":
        case "ArrowRight":
          moveTo = matchedSibling(current, '[role="menuitem"]', "next") || resultList.firstElementChild;
          break;
        case "ArrowUp":
        case "ArrowLeft":
          moveTo = matchedSibling(current, '[role="menuitem"]', "previous") || resultList.lastElementChild;
          break;
      }
      if (moveTo !== void 0) {
        moveTo.focus();
        e.preventDefault();
      }
    }, toggleStates = function() {
      let target = this.parentNode.querySelector('[role="menu"]'), nowCollapsed = this.getAttribute("aria-expanded") === "true";
      target.setAttribute("aria-hidden", nowCollapsed);
      this.setAttribute("aria-expanded", !nowCollapsed);
      if (!nowCollapsed) {
        target.classList[target.getBoundingClientRect().right > window.innerWidth ? "add" : "remove"]("realign");
        target.firstElementChild.focus();
      }
    };
    toggleEls.forEach((el) => {
      init(el);
    });
  }

  // _src/js/timeline.js
  function timeline_default() {
    const timelines = document.querySelectorAll(".timeline"), itemObserver = new IntersectionObserver((obs) => {
      obs.forEach((ob) => {
        if (ob.isIntersecting) {
          ob.target.querySelector(".timeline-inner").classList.add("show-inner");
          itemObserver.unobserve(ob.target);
        }
      });
    }, {
      threshold: 0.5
    }), timelineObserver = new IntersectionObserver((obs) => {
      obs.forEach((ob) => {
        if (ob.isIntersecting) {
          drawLine(ob.target);
        }
      });
    }), drawLine = (timeline) => {
      const timelineCards = timeline.querySelectorAll(".timeline-item"), timelineHeadings = timeline.querySelectorAll(".hed");
      timeline.addEventListener("transitionend", (e) => {
        setTimeout(() => {
          timelineCards.forEach((card, i) => setTimeout(() => card.classList.add("show-card"), i * 200));
        }, 200);
      });
      timelineHeadings.forEach((hed, i) => setTimeout(() => hed.classList.add("show-hed"), i * 200));
      timeline.classList.add("show-line");
      timeline.classList.remove("hide-line");
      timelineCards.forEach((card) => itemObserver.observe(card));
    };
    timelines.forEach((timeline) => timelineObserver.observe(timeline));
  }

  // _src/js/map.js
  function map_default() {
    const mapSelector = ".interactive-map", maps = document.querySelectorAll(mapSelector), initializeCard = (card) => {
      const included = card.dataset.includes && card.dataset.includes.split(","), highlightColor = card.dataset.highlightColor;
      included.forEach((state) => {
        const statePath = map.querySelector(`#${state}`);
        if (statePath) {
          statePath.style.fill = highlightColor;
        }
      });
      card.addEventListener("mouseover", highlightRegion);
      card.addEventListener("mouseout", inactiveRegion);
      card.addEventListener("focusin", highlightRegion);
      card.addEventListener("focusout", inactiveRegion);
    }, highlightRegion = function(card) {
      const region = this.id, highlightColor = this.dataset.highlightColor, included = this.dataset.includes && this.dataset.includes.split(",");
      included && included.forEach((state) => {
        const statePath = map.querySelector(`#${state}`);
        if (!statePath) {
          return;
        }
        statePath.classList.add("active-region");
      });
    }, inactiveRegion = function() {
      this.closest(mapSelector).querySelectorAll(".active-region").forEach((state) => {
        state.classList.remove("active-region");
      });
    }, highlightCard = function() {
      const state = this.id, card = document.querySelector(`[data-includes*="${state}"]`);
      let included, highlightColor;
      if (!card) {
        return;
      }
      included = card.dataset.includes && card.dataset.includes.split(",");
      highlightColor = card.dataset.highlightColor;
      included && included.forEach((stateId) => {
        const state2 = map.querySelector(`#${stateId}`);
        if (!state2) {
          return;
        }
        state2.classList.add("active-region");
        state2.style.fill = highlightColor;
      });
      card && card.classList.add("active-card");
    }, mapNavigation = function() {
      const state = this.id, card = this.closest(mapSelector).querySelector(`[data-includes*="${state}"]`);
      window.location.href = card.href;
    };
    maps.forEach((map2) => {
      const cards = map2.querySelectorAll(".card-location"), paths = map2.querySelectorAll("svg path");
      cards.forEach(initializeCard);
      paths.forEach((path) => {
        path.addEventListener("click", mapNavigation);
        path.addEventListener("mouseover", highlightCard);
        path.addEventListener("mouseout", function(e) {
          const state = this.id, cards2 = map2.querySelectorAll(`[data-includes*="${state}"]`);
          cards2.forEach((card) => {
            const included = card.dataset.includes && card.dataset.includes.split(","), highlightColor = card.dataset.highlightColor;
            included.forEach((stateId) => {
              const state2 = map2.querySelector(`#${stateId}`);
              if (!state2) {
                return;
              }
              state2.classList.remove("active-region");
            });
            card.classList.remove("active-card");
          }, { once: true });
        });
      });
    });
  }

  // _src/js/media.js
  function media_default() {
    const mediablocks = document.querySelectorAll("[data-media]"), createiframe = (src, poster) => {
      const iframe = document.createElement("iframe");
      iframe.src = src + "?autoplay=1";
      iframe.setAttribute("allow", "allowfullscreen");
      iframe.setAttribute("allow", "autoplay");
      return iframe;
    };
    mediablocks.forEach((media) => {
      media.addEventListener("click", function(e) {
        const source = this.dataset.media, player = createiframe(source, this), poster = this.querySelector("img").src;
        this.parentNode.style.backgroundImage = "url(" + poster + ")";
        this.parentNode.insertBefore(player, this);
        this.remove();
        e.preventDefault();
      });
    });
  }

  // _src/js/statistic.js
  function statistic_default() {
    const opt = {
      "duration": 2e3,
      "frameDuration": 2e3 / 60,
      "easing": (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2
    }, counters = document.querySelectorAll("[data-counter]"), statObserver = new IntersectionObserver((obs) => {
      obs.forEach((ob) => {
        if (ob.isIntersecting) {
          ob.target.classList.add("statistic-visible");
          const headings = ob.target.querySelectorAll(".type-hed");
          headings.forEach((el, i) => {
            const textNode = [...el.childNodes].filter((node) => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== "" && !isNaN(parseFloat(node.nodeValue))), value = textNode.map((el2) => el2.textContent).join(""), valueFloat = parseFloat(value.replace(/,/g, ""), 10), totalFrames = Math.round(opt.duration / opt.frameDuration + i * 10);
            [...textNode].forEach((node) => node.nodeValue = 0);
            let frame = 0;
            const ticker = setInterval(() => {
              frame++;
              const currentCount = Math.round(valueFloat * opt.easing(frame / totalFrames));
              [...textNode].forEach((node) => {
                node.nodeValue = formatNumber(currentCount);
              });
              if (valueFloat === currentCount || frame === totalFrames) {
                clearInterval(ticker);
              }
            }, opt.frameDuration);
          });
          statObserver.unobserve(ob.target);
        }
      });
    }, {
      threshold: 0.5
    }), formatNumber = function(num) {
      const regEx = /(\d+)(\d{3})/;
      let numStr = num.toString();
      while (regEx.test(numStr)) {
        numStr = numStr.replace(regEx, "$1,$2");
      }
      return numStr;
    };
    counters.forEach((statblock) => {
      statObserver.observe(statblock);
    });
  }

  // _src/js/form-disclose.js
  function form_disclose_default() {
    let trigger = document.querySelectorAll("[data-form-disclose]"), init = function(el) {
      const target = document.querySelector(`#${el.dataset.formDisclose}`);
      if (el.validity.valid === false || el.value == false) {
        target.setAttribute("aria-hidden", true);
        el.setAttribute("aria-expanded", false);
        el.addEventListener("change", (e) => {
          el.validity.valid && target.removeAttribute("aria-hidden");
        });
        el.addEventListener("keydown", (e) => {
          el.validity.valid && target.removeAttribute("aria-hidden");
        });
      }
    };
    trigger.forEach(init);
  }

  // _src/js/bundle.js
  disclosure_default();
  toggle_default();
  menu_default();
  timeline_default();
  map_default();
  media_default();
  statistic_default();
  form_disclose_default();
})();
