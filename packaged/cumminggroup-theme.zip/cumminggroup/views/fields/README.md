# Field templates

These twig fragments are used to render specific fields or groups of fields. Generally,
they simply extend existing partials or blocks — i.e., they're a mapping between the
WordPress post structure and ACF fields and the existing site components.
